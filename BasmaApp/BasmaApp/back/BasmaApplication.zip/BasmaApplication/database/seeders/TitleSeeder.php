<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\Title;
use App\Models\SubjectClass;
use App\Models\Subject;
use App\Models\Classroom;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\DB;
class TitleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Define multiple titles for each subject by classroom
        $titlesByClassAndSubject = [
            1 => [
                'العلوم' => [
                    'جسم الإنسان',
                    'دورة الماء',
                    'الكائنات الحية',
                ],
                'الرياضيات' => [
                    'الأعداد',
                    'الجمع والطرح',
                    'الأشكال الهندسية',
                ],
                'اللغة الإنجليزية' => [
                    'الأحرف الإنجليزية',
                    'الأرقام بالإنجليزية',
                    'الألوان',
                ],
                'اللغة العربية' => [
                    'الأحرف العربية',
                    'الأسماء',
                    'الأفعال',
                ],
            ],
            2 => [
                'العلوم' => [
                    'الجهاز التنفسي',
                    'الجهاز الهضمي',
                    'الكهرباء والمغناطيسية',
                ],
                'الرياضيات' => [
                    'الجمع والطرح',
                    'الضرب والقسمة',
                    'الأشكال الثلاثية الأبعاد',
                ],
                'اللغة الإنجليزية' => [
                    'الأسماء بالإنجليزية',
                    'الأفعال بالإنجليزية',
                    'الأزمنة البسيطة',
                ],
                'اللغة العربية' => [
                    'الأسماء',
                    'الأفعال',
                    'الضمائر',
                ],
            ],
            3 => [
                'العلوم' => [
                    'الجهاز الهضمي',
                    'الدورة الدموية',
                    'الجهاز العصبي',
                ],
                'الرياضيات' => [
                    'الضرب والقسمة',
                    'الجمع والطرح',
                    'المعادلات البسيطة',
                ],
                'اللغة الإنجليزية' => [
                    'الأفعال بالإنجليزية',
                    'الضمائر بالإنجليزية',
                    'الجمل البسيطة',
                ],
                'اللغة العربية' => [
                    'الأفعال بالعربية',
                    'الجمل الاسمية',
                    'الجمل الفعلية',
                ],
            ],
            4 => [
                'العلوم' => [
                    'الخلية',
                    'التكاثر في النباتات',
                    'الجهاز التنفسي',
                ],
                'الرياضيات' => [
                    'الأعداد الأولية',
                    'المعادلات الخطية',
                    'الكسور',
                ],
                'اللغة الإنجليزية' => [
                    'الجمل بالإنجليزية',
                    'الأزمنة المستمرة',
                    'الصفات',
                ],
                'اللغة العربية' => [
                    'المبتدأ والخبر',
                    'النعت والمنعوت',
                    'الضمائر المنفصلة',
                ],
            ],
            // يمكنك إضافة المزيد من الصفوف والمواد والدروس هنا
        ];

        // Get all subject classes
        $subjectClasses = SubjectClass::all();

        // Loop through each subject class and create titles
        foreach ($subjectClasses as $subjectClass) {
            $classroom = $subjectClass->classroom;
            $subject = $subjectClass->subject;

            if (isset($titlesByClassAndSubject[$classroom->id][$subject->name])) {
                foreach ($titlesByClassAndSubject[$classroom->id][$subject->name] as $title) {
                    Title::create([
                        'subject_class_id' => $subjectClass->id,
                        'name' => $title,
                    ]);
                }
            }
        }
    }
}
