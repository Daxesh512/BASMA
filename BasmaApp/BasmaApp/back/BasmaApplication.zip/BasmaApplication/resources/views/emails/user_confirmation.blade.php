<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration Confirmation</title>
</head>
<body>
    <h1>Thank You for Registering </h1>
    <p>Your registration has been successfully completed. We appreciate your interest in our platform.</p>
    <p>Your activation code is: <strong>{{ $code }}</strong>.</p>
</body>
</html>