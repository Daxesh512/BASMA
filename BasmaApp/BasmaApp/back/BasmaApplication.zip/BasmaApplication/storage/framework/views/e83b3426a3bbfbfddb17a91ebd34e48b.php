<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <!-- Include CSS files if needed -->
</head>
<body>
<div id="app">
    <h1>Chat Room</h1>
    <div id="messages">
        <!-- Messages will be displayed here -->
    </div>
    <form id="message-form">
        <input type="text" id="message" placeholder="Type your message here">
        <input type="hidden" id="receiver_id" value="RECEIVER_ID"> <!-- Replace RECEIVER_ID with actual receiver ID -->
        <button type="submit">Send</button>
    </form>
</div>

<!-- Include Axios and Pusher -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.21.1/axios.min.js"></script>
<script src="https://js.pusher.com/7.0/pusher.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Directly setting the token (for demo purposes only, use localStorage in production)
        const token = '3|z4vrXVSgepCex2h6QesgwK7OyYPOlsMYQHIvGrZgb09fdaea';
        const messagesDiv = document.getElementById('messages');
        const messageForm = document.getElementById('message-form');
        const messageInput = document.getElementById('message');
        const receiverIdInput = document.getElementById('receiver_id');

        // Function to fetch messages
        async function fetchMessages(receiver_id) {
            try {
                const response = await axios.get(`/api/messages/${receiver_id}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                const messages = response.data;
                messagesDiv.innerHTML = '';
                messages.forEach(message => {
                    const messageElement = document.createElement('div');
                    messageElement.textContent = `${message.sender_id}: ${message.message}`;
                    messagesDiv.appendChild(messageElement);
                });
            } catch (error) {
                console.error('Error fetching messages', error);
            }
        }

        // Function to send a new message
        messageForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const message = messageInput.value;
            const receiver_id = receiverIdInput.value;
            try {
                await axios.post('/api/send-message', {
                    message: message,
                    receiver_id: receiver_id
                }, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                messageInput.value = '';
                fetchMessages(receiver_id);
            } catch (error) {
                console.error('Error sending message', error);
            }
        });

        // Fetch messages on load
        fetchMessages(receiverIdInput.value);

        // Set up Pusher for real-time updates
        Pusher.logToConsole = true;
        const pusher = new Pusher('a1d40d932b2bd22d28ea', {
            cluster: 'eu',
            authEndpoint: '/broadcasting/auth',
            auth: {
                headers: { Authorization: `Bearer ${token}` }
            }
        });

        const channel = pusher.subscribe('private-chat.' + receiverIdInput.value);
        channel.bind('App\\Events\\MessageSent', function(data) {
            fetchMessages(receiverIdInput.value);
        });
    });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BasmaApplication\resources\views/chat.blade.php ENDPATH**/ ?>